package com.example.join.service;

import com.example.join.entity.User;
import com.example.join.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    public List<User> findAll() {
        return userRepository.findAll();
    }
    
    public void registerUser(String username, String name, String password, String region, String prefecture) {
    	//입력한 username이 이미 db에 있는지 확인
    	Optional<User> existingUser = userRepository.findByUsername(username);
    	//중복된 ID면 예외 발생
    	if (existingUser.isPresent()) {
    		throw new IllegalArgumentException("このIDは既に使用されています。");
    	}
    	//중복 아니면 회원가입 진행
        User user = new User();
        user.setUsername(username);
        user.setName(name);
        user.setPassword(password);
        user.setRegion(region);
        user.setPrefecture(prefecture);
        userRepository.save(user);
    }
    
    public User login(String username, String password) {
        System.out.println("=== UserService.login ===");
        System.out.println("찾는 username: " + username);
        System.out.println("입력한 password: " + password);

        Optional<User> userOpt = userRepository.findByUsername(username);

        if(userOpt.isPresent()) {
            User user = userOpt.get();
            System.out.println("DB에서 찾은 user: " + user.getUsername());
            System.out.println("DB의 password: " + user.getPassword());

            if(user.getPassword().equals(password)) {
                System.out.println("✅ 비밀번호 일치!");
                return user;
            } else {
                System.out.println("❌ 비밀번호 불일치!");
                return null;
            }
        } else {
            System.out.println("❌ 사용자를 찾을 수 없음!");
            return null;
        }
    }
    
    // 
    public void logout(HttpSession session) {
        session.invalidate();
    }
    //db에서 사용자 삭제
    @Transactional
    public void withdrawUser(Long userId) {
    	userRepository.deleteById(userId);
    }
}